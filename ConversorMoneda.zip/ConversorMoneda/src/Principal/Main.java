/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;


import conversormoneda.Inicio;
import Controlador.ControladorInicio;
import Controlador.ControladorSeleccion;
import conversormoneda.ADolar;
import conversormoneda.Seleccion;
import Controlador.ControladorConversion;
import Controlador.ControladorVolver;
import conversormoneda.Volver;
import conversormoneda.Temperatura;
import Controlador.ControladorTemperatura;
import conversormoneda.ConversorTemperatura;
import Controlador.ControladorCoversionTemp;



public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Seleccion seleccion = new Seleccion();
        Inicio inicio=new Inicio();
        ADolar dolar=new ADolar();
        Volver volver=new Volver();
        Temperatura temp= new Temperatura();
        ConversorTemperatura CT = new ConversorTemperatura();
        
        
        
        ControladorInicio CI=new ControladorInicio(seleccion, inicio, dolar, volver, temp, CT);
        ControladorSeleccion CS=new ControladorSeleccion(dolar, inicio, seleccion);
        ControladorConversion CC=new ControladorConversion(dolar,CS, seleccion, volver);
        ControladorVolver CV=new ControladorVolver(volver, inicio);
        ControladorTemperatura ConT=new ControladorTemperatura(inicio, temp, CT);
        ControladorCoversionTemp CCT=new ControladorCoversionTemp(ConT, temp, CT);
        CI.iniciar();
        inicio.setVisible(true);
    }
    
}
