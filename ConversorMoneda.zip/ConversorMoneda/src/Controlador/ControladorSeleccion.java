/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import conversormoneda.ADolar;
import conversormoneda.Inicio;
import conversormoneda.Seleccion;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
public class ControladorSeleccion implements ActionListener {
    
    public String eleccion;
    private ADolar dolar;
    private Inicio inicio;
    private Seleccion seleccion;

    public ControladorSeleccion(ADolar dolar, Inicio inicio, Seleccion seleccion) {
        this.dolar = dolar;
        this.inicio=inicio;
        this.seleccion = seleccion;
        this.seleccion.btnContinuar.addActionListener(this);
        this.seleccion.btnRetroceder.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==seleccion.btnContinuar) {
            eleccion=(String) seleccion.Conversiones.getSelectedItem();
            
            dolar.setVisible(true);
            seleccion.dispose();
            
        }
        
        if (e.getSource()==seleccion.btnRetroceder) {
            retroceder();
        }
    }
    
    public void retroceder(){
        inicio.setVisible(true);
        seleccion.dispose();
    }
    
    
    
    
}
