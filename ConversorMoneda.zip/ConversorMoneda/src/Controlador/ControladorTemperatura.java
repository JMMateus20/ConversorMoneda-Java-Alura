/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;
import conversormoneda.Inicio;
import conversormoneda.Temperatura;
import conversormoneda.ConversorTemperatura;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class ControladorTemperatura implements ActionListener {
    private Inicio inicio;
    private Temperatura temp;
    private ConversorTemperatura CT;
    public String eleccion;

    public ControladorTemperatura(Inicio inicio, Temperatura temp, ConversorTemperatura CT) {
        this.inicio = inicio;
        this.temp = temp;
        this.CT = CT;
        this.temp.btnAvanzar.addActionListener(this);
        this.temp.btnRetroceder.addActionListener(this);
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        if (e.getSource()==temp.btnAvanzar) {
            eleccion=(String) temp.Temperaturas.getSelectedItem();
            
            CT.setVisible(true);
            temp.dispose();
           
        }
        if (e.getSource()==temp.btnRetroceder) {
            inicio.setVisible(true);
            temp.dispose();
        }
    }
    
    
    
}
