/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import conversormoneda.ADolar;
import conversormoneda.Seleccion;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import conversormoneda.Volver;


public class ControladorConversion implements ActionListener {

    private ADolar dolar;
    private ControladorSeleccion CS;
    private Seleccion seleccion;
    private Volver volver;

    public ControladorConversion(ADolar dolar, ControladorSeleccion CS, Seleccion seleccion, Volver volver) {
        this.dolar = dolar;
        this.CS = CS;
        this.volver=volver;
        this.seleccion=seleccion;
        dolar.btnConvertir.addActionListener(this);
        dolar.btnAtras.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == dolar.btnConvertir) {
            if (dolar.txtValor.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Ingrese un valor por favor");
            } else {
                if (CS.eleccion == "De peso a Dolar") {
                    double peso = Double.parseDouble(dolar.txtValor.getText());
                    double Adolar = peso / 4896.91;
                    String redondeo = String.format("%.5f", Adolar);

                    JOptionPane.showMessageDialog(null, "el valor en dólares de " + (int) peso + " pesos " + " es " + redondeo + " dólares");
                    avanzar();
                } else if (CS.eleccion == "De peso a Euro") {
                    double peso = Double.parseDouble(dolar.txtValor.getText());
                    double Euro = peso * 0.00019;
                    String redondeo = String.format("%.5f", Euro);

                    JOptionPane.showMessageDialog(null, "el valor en Euros de " + (int) peso + " pesos " + " es " + redondeo + " Euros");
                    avanzar();
                } else if (CS.eleccion == "De peso a Libra") {
                    double peso = Double.parseDouble(dolar.txtValor.getText());

                    double libra = peso * 0.00017;
                    String redondeo = String.format("%.5f", libra);

                    JOptionPane.showMessageDialog(null, "el valor en Libras de " + (int) peso + " pesos " + " es " + redondeo + " Libras");
                    avanzar();
                } else if (CS.eleccion == "De peso a Yen") {
                    double peso = Double.parseDouble(dolar.txtValor.getText());
                    double yen = peso * 0.027;
                    String redondeo = String.format("%.5f", yen);

                    JOptionPane.showMessageDialog(null, "el valor en Yenes de " + (int) peso + " pesos " + " es " + redondeo + " Yenes");
                    avanzar();
                    
                } else if (CS.eleccion == "De peso a Won Coreano") {
                    double peso = Double.parseDouble(dolar.txtValor.getText());
                    double won = peso * 0.26;
                    String redondeo = String.format("%.5f", won);

                    JOptionPane.showMessageDialog(null, "el valor en Wones de " + (int) peso + " pesos " + " es " + redondeo + " Wones");
                    
                    avanzar();
                }
                dolar.txtValor.setText("");
                
            }

        }
        
        if (e.getSource()==dolar.btnAtras) {
            seleccion.setVisible(true);
            dolar.dispose();
        }

    }
    
    public void avanzar(){
       
        volver.setVisible(true);
        dolar.dispose();
    }
    
    

}
