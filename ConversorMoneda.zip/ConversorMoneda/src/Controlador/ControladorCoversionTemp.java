/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;
import Controlador.ControladorTemperatura;
import conversormoneda.Temperatura;
import conversormoneda.ConversorTemperatura;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class ControladorCoversionTemp implements ActionListener {
    
    private ControladorTemperatura CT;
    private Temperatura temp;
    private ConversorTemperatura ConT;

    public ControladorCoversionTemp(ControladorTemperatura CT, Temperatura temp, ConversorTemperatura ConT) {
        this.CT = CT;
        this.temp = temp;
        this.ConT=ConT;
        this.ConT.btnConvertir.addActionListener(this);
        this.ConT.btnRegresar.addActionListener(this);
        this.ConT.btnLimpiar.addActionListener(this);
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==ConT.btnConvertir) {
            if (CT.eleccion=="De centigrados a Farenheit") {
                double inicial=Double.parseDouble(ConT.txtIngreso.getText());
                double resultado=(inicial*1.8)+32;
                String redondeo = String.format("%.2f", resultado);
                ConT.txtResultado.setText(redondeo + " ºF");
                
            }else if (CT.eleccion=="De centigrados a Kelvin") {
                double inicial=Double.parseDouble(ConT.txtIngreso.getText());
                double resultado=inicial+273.15;
                String redondeo = String.format("%.2f", resultado);
                ConT.txtResultado.setText(redondeo + " ºK");
                
            }else if (CT.eleccion=="De centigrados a Rankine") {
                double inicial=Double.parseDouble(ConT.txtIngreso.getText());
                double resultado=(inicial*1.8)+491.67;
                String redondeo = String.format("%.2f", resultado);
                ConT.txtResultado.setText(redondeo + " ºR");
                
            }else if (CT.eleccion=="De Farenheit a centigrados") {
                double inicial=Double.parseDouble(ConT.txtIngreso.getText());
                double resultado=(inicial-32)*0.555556;
                String redondeo = String.format("%.2f", resultado);
                ConT.txtResultado.setText(redondeo + " ºC");
            }else if (CT.eleccion=="De Farenheit a Kelvin") {
                double inicial=Double.parseDouble(ConT.txtIngreso.getText());
                double resultado=(inicial-32)*0.555556+(273.15);
                String redondeo = String.format("%.2f", resultado);
                ConT.txtResultado.setText(redondeo + " ºK");
                
            }else if (CT.eleccion=="De Farenheit a Rankine") {
                double inicial=Double.parseDouble(ConT.txtIngreso.getText());
                double resultado=inicial+459.67;
                String redondeo = String.format("%.2f", resultado);
                ConT.txtResultado.setText(redondeo + " ºR");
            }else if (CT.eleccion=="De Kelvin a Centigrados") {
                double inicial=Double.parseDouble(ConT.txtIngreso.getText());
                double resultado=inicial-273.15;
                String redondeo = String.format("%.2f", resultado);
                ConT.txtResultado.setText(redondeo + " ºC");
            }else if (CT.eleccion=="De Kelvin a Farenheit") {
                double inicial=Double.parseDouble(ConT.txtIngreso.getText());
                double resultado=((inicial-273.15)*(1.8))+32;
                String redondeo = String.format("%.2f", resultado);
                ConT.txtResultado.setText(redondeo + " ºF");
            }else if (CT.eleccion=="De Kelvin a Rankine") {
                double inicial=Double.parseDouble(ConT.txtIngreso.getText());
                double resultado=inicial*1.8;
                String redondeo = String.format("%.2f", resultado);
                ConT.txtResultado.setText(redondeo + " ºR");
            }else if (CT.eleccion=="De Rankine a Centigrados") {
                double inicial=Double.parseDouble(ConT.txtIngreso.getText());
                double resultado=(inicial-491.67)*0.5555556;
                String redondeo = String.format("%.2f", resultado);
                ConT.txtResultado.setText(redondeo + " ºC");
            }else if (CT.eleccion=="De Rankine a Farenheit") {
                double inicial=Double.parseDouble(ConT.txtIngreso.getText());
                double resultado=inicial-459.67;
                String redondeo = String.format("%.2f", resultado);
                ConT.txtResultado.setText(redondeo + " ºF");
                
            }else if (CT.eleccion=="De Rankine a Kelvin") {
                double inicial=Double.parseDouble(ConT.txtIngreso.getText());
                double resultado=inicial*0.555556;
                String redondeo = String.format("%.2f", resultado);
                ConT.txtResultado.setText(redondeo + " ºK");
                
            }
        }
        if (e.getSource()==ConT.btnRegresar) {
            ConT.txtIngreso.setText("");
            ConT.txtResultado.setText("");
            temp.setVisible(true);
            ConT.dispose();
        }
        
        if (e.getSource()==ConT.btnLimpiar) {
            ConT.txtIngreso.setText("");
            ConT.txtResultado.setText("");
        }
    }
    
    
    
}
