/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;


import conversormoneda.ADolar;
import conversormoneda.Inicio;
import conversormoneda.Seleccion;
import conversormoneda.Volver;
import conversormoneda.Temperatura;
import conversormoneda.ConversorTemperatura;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorInicio implements ActionListener {
    private Inicio inicio;
    private ADolar dolar;
    private Seleccion seleccion;
    private Volver volver;
    private Temperatura temp;
    private ConversorTemperatura CT;
    

    public ControladorInicio(Seleccion seleccion, Inicio inicio, ADolar dolar, Volver volver, Temperatura temp, ConversorTemperatura CT) {
        this.seleccion = seleccion;
        this.dolar=dolar;
        this.inicio = inicio;
        this.volver=volver;
        this.temp=temp;
        this.CT=CT;
        this.inicio.btnContinuar.addActionListener(this);
        this.inicio.btnSalir.addActionListener(this);
    }
    
    public void iniciar() {
        seleccion.setTitle("Seleccionar");
        inicio.setTitle("Inicio");
        
        seleccion.setLocationRelativeTo(null);
        inicio.setLocationRelativeTo(null);
        dolar.setLocationRelativeTo(null);
        volver.setLocationRelativeTo(null);
        temp.setLocationRelativeTo(null);
        CT.setLocationRelativeTo(null);
        
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==inicio.btnContinuar) {
            if (inicio.Opciones.getSelectedItem()=="Conversor moneda") {
                seleccion.setVisible(true);
                inicio.dispose();
            }else if (inicio.Opciones.getSelectedItem()=="Conversor temperatura") {
                temp.setVisible(true);
                inicio.dispose();
            }
            
            
            
        }
        
        if (e.getSource()==inicio.btnSalir) {
            System.exit(0);
        }
        
    }
    
    
    
}
