/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;
import conversormoneda.Volver;
import conversormoneda.Inicio;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorVolver implements ActionListener {
    
    private Volver volver;
    private Inicio inicio;

    public ControladorVolver(Volver volver, Inicio inicio) {
        this.volver = volver;
        this.inicio = inicio;
        this.volver.btnVolver.addActionListener(this);
        this.volver.btnSalir.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==volver.btnVolver) {
            inicio.setVisible(true);
            volver.dispose();
        }
        if (e.getSource()==volver.btnSalir) {
            System.exit(0);
        }
    }
    
    
    
}
